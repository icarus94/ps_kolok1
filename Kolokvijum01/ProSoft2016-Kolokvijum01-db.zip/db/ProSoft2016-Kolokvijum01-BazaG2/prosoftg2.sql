/*
SQLyog Ultimate v9.50 
MySQL - 5.6.20 : Database - prosoftg2
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`prosoftg2` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `prosoftg2`;

/*Table structure for table `lokacija` */

DROP TABLE IF EXISTS `lokacija`;

CREATE TABLE `lokacija` (
  `LokacijaID` int(11) NOT NULL,
  `Naziv` varchar(50) DEFAULT NULL,
  `PocetakGradnje` date DEFAULT NULL,
  `ZavrsetakGradnje` date DEFAULT NULL,
  PRIMARY KEY (`LokacijaID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `lokacija` */

insert  into `lokacija`(`LokacijaID`,`Naziv`,`PocetakGradnje`,`ZavrsetakGradnje`) values (1,'Naselje Stepa Stepanovic','2016-01-01','2016-04-30'),(2,'Naselje Stadion','2016-02-01','2016-05-31'),(3,'Univerzitetsko naselje','2016-03-01','2016-06-30'),(4,'Centar','2016-04-01','2016-07-31');

/*Table structure for table `radnik` */

DROP TABLE IF EXISTS `radnik`;

CREATE TABLE `radnik` (
  `RadnikID` int(11) NOT NULL,
  `Ime` varchar(50) DEFAULT NULL,
  `Prezime` varchar(50) DEFAULT NULL,
  `Specijalizacija` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`RadnikID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `radnik` */

insert  into `radnik`(`RadnikID`,`Ime`,`Prezime`,`Specijalizacija`) values (1,'Ivana','Ivanovic','arhitekta'),(2,'Marko','Markovic','gradjevinski inzenjer'),(3,'Marija','Markovic','administrativni radnik'),(4,'Jovan','Jovanovic','keramicar'),(5,'Ivan','Ivkovic','zidar'),(6,'Dragan','Mitrovic','stolar'),(7,'Pavle','Pavlovic','moler');

/*Table structure for table `raspored` */

DROP TABLE IF EXISTS `raspored`;

CREATE TABLE `raspored` (
  `RasporedID` int(11) NOT NULL,
  `BrojSati` int(11) DEFAULT NULL,
  `Datum` date DEFAULT NULL,
  `LokacijaID` int(11) DEFAULT NULL,
  `RadnikID` int(11) DEFAULT NULL,
  PRIMARY KEY (`RasporedID`),
  KEY `LokacijaID` (`LokacijaID`),
  KEY `RadnikID` (`RadnikID`),
  CONSTRAINT `raspored_ibfk_1` FOREIGN KEY (`LokacijaID`) REFERENCES `lokacija` (`LokacijaID`),
  CONSTRAINT `raspored_ibfk_2` FOREIGN KEY (`RadnikID`) REFERENCES `radnik` (`RadnikID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `raspored` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
